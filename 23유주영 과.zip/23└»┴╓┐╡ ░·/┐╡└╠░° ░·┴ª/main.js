let canvas = document.querySelector('#canvas');
let ctx = canvas.getContext('2d'); 


canvas.width = window.innerWidth - 200;
canvas.height = window.innerHeight - 100;

//공룡 이미지
let dinoImg = new Image();
dinoImg.src = 'dino.png';
let dino = {
    x: 0,
    y: 200, 
    width: 40,
    height: 50, 
    draw() {
        //ctx.fillStyle = 'green';
        //ctx.fillRect(this.x, this.y, this.width, this.height);
        ctx.drawImage(dinoImg, this.x, this.y);
    }
}

//나무 이미지
var cactusImg = new Image();
cactusImg.src = 'tree.png';

class Cactus {
    constructor() {
        this.width = 20;
        this.height = 50;
        this.x = 1000;
        this.y = 200;
    }
    draw() {
        //ctx.fillStyle = 'red';
        //ctx.fillRect(this.x, this.y, this.width, this.height);
        ctx.drawImage(cactusImg, this.x, this.y);
    }
}

var rockImg = new Image();
rockImg.src = 'tree2.png';

class Rock {
    constructor() {
        this.width = 20;
        this.height = 50;
        this.x = 1000;
        this.y = 200;
    }
    draw() {
        //ctx.fillStyle = 'red';
        //ctx.fillRect(this.x, this.y, this.width, this.height);
        ctx.drawImage(rockImg, this.x, this.y);
    }
}
//돌 이미지


//변수값
let timer = 0;
let cactusArr = [];
let gameState = 0; 
let jumpState = 0; 
let jumpTimer = 0;
let animation;
let life = 5;
let score = 0;
let rockArr = [];
let jumpCooldown = false;

function frameAction() {
    animation = requestAnimationFrame(frameAction);
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    timer += 1; 
    
    if (timer % 150 === 0) {
        let randomValue = Math.random();
    
        if (randomValue < 0.7) {
            let cactus = new Cactus();
            cactusArr.push(cactus);
        }
    }

    if (score >= 30 && timer % 180 === 0) {
        let randomValue = Math.random();
        
        if (randomValue < 0.7) {
            let rock = new Rock(); 
            rockArr.push(rock); 
        }
    }

    // cactusArr 배열의 장애물 움직임 처리
    cactusArr.forEach((a, i, o) => {
        if (a.x < 0) {
            o.splice(i, 1);
            score += 10;
            document.querySelector('#score').innerHTML = score;
        } else if (collisionDetection(dino, a) < 0) {
            o.splice(i, 1);
        }
        
        a.x -= 2;
        
        a.draw();

        if (score >= 100) {
            // 클리어 화면 표시
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = 'black';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
    
            ctx.font = '30px Arial';
            ctx.fillStyle = 'white';
            ctx.fillText('Game Clear! 23-소프트웨어과-유주영', 80, canvas.height / 2);
            cancelAnimationFrame(animation);
        }
    });




    // rockArr 배열의 장애물 움직임 처리
    rockArr.forEach((a, i, o) => {
        if (a.x < 0) {
            o.splice(i, 1);
            score += 20
            document.querySelector('#score').innerHTML = score;
        } else if (collisionDetection(dino, a) < 0) {
            o.splice(i, 1);
        }
        
        a.x -= 3;
        
        a.draw();

        if (score >= 100) {
            // 클리어 화면 표시
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = 'black';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
    
            ctx.font = '30px Arial';
            ctx.fillStyle = 'white';
            ctx.fillText('Game Clear! 23-소프트웨어과-유주영', 80, canvas.height / 2);
            cancelAnimationFrame(animation);
        }
    });

    // 점프 및 기타 로직 추가...
    if (jumpState == 1) {
        jumpTimer++; 
        dino.y -= 2;
    }
    if (jumpTimer > 50) {
        jumpState = 0;
        jumpTimer = 0;
    }
    if (jumpState == 0) {
        if (dino.y < 200) {
            dino.y += 2;
        }
    }
    drawLine();
    dino.draw();
}

//게임시작
document.addEventListener('keydown', (e)=>{
    if(e.code == 'Space'){
        if(gameState == 0){
            gameState = 1; 
            frameAction();
            document.querySelector('h2').style.display = 'none';
            document.querySelector('h4').style.display = 'none';
            document.querySelector('img').style.display = 'none';
        } else if(gameState == 1 && !jumpCooldown){ 
            jumpState = 1;
            jumpCooldown = true; 
            setTimeout(() => {
                jumpCooldown = false; 
            }, 650);
        }
    }
})

//충돌감지
function collisionDetection(dino, cactus){ 
    let xValue = cactus.x - ( dino.x + dino.width );
    let yValue = cactus.y - ( dino.y + dino.height );
    if( xValue < 0 && yValue < 0 ){ 
        
        life--;
        document.querySelector('#life').innerHTML = life;
        if(life == 0){  //게임오버 화면
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = 'black';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
    
            ctx.font = '30px Arial';
            ctx.fillStyle = 'white';
            ctx.fillText('Game Over... 다시 하세요', 80, canvas.height / 2);
            cancelAnimationFrame(animation);
        }
        return -1;
    } else {
        return 1;
    }
}


function getRandomInt(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min)) + min; 
}

function drawLine(){
    ctx.beginPath();
    ctx.moveTo(0, 250);
    ctx.lineTo(2000, 250);
    ctx.stroke();
}







